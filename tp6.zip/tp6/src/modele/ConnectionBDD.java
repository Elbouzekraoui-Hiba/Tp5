package modele;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ConnectionBDD {
	private String URL = "jdbc:derby:cciDB;create=true";
	private String DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
	private String LOGIN = "";
	private String PWD = "";
	private Connection cn;
	
	public ConnectionBDD() {
		try {
			Class.forName(DRIVER) ;
			cn =DriverManager.getConnection(URL, LOGIN, PWD);
			System.out.println( "Connection a la base de donnees");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e. printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e. printStackTrace() ;
		}
	}
	public void ajoutBDD() {
		Statement st;
		try {
			st = cn.createStatement();
			st.execute("create table eleve (id int, nom varchar(20), body varchar(20) )") ;
			st.executeUpdate("INSERT INTO eleve VALUES (1, 'DURAND' , ' Jacques')");
			st.executeUpdate("INSERT INTO eleve VALUES (2, 'DUPOND' , 'Daniel' )");
			st.executeUpdate("INSERT INTO eleve VALUES (3, 'Lai' , 'Johan' )");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public ArrayList<Post> affichage() throws SQLException {
	        Statement st = cn.createStatement();
	        ResultSet rs = st.executeQuery("SELECT * FROM eleve");
	        ArrayList<Post> ar = new ArrayList<>();
	        
	        while (rs.next()) {
	            Post p = new Post(rs.getInt("id"), rs.getString("nom"), rs.getString("body"));
	            ar.add(p);
	        }

	        return ar;
	    }
}
