package tp3;

import java.net.URL;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.ResourceBundle;

import modele.ConnectionBDD;
import modele.Post;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;


public class VueController implements Initializable{
	
	@FXML
    private Button init;
	@FXML
    private Button select;
	@FXML
    private TextArea text;

    private ConnectionBDD connectionBDD;
    @Override
    public void initialize(URL arg0, ResourceBundle arg1) {
        this.connectionBDD = new ConnectionBDD();

    }
    
    public void ajoutBDD() {
    	connectionBDD.ajoutBDD();
    }
    public void affiche() throws SQLException {
        ArrayList<Post> ar = connectionBDD.affichage();

        for (int i=0; i<ar.size(); i++) {
            text.setText(text.getText() + " ");
            text.setText(text.getText() + ar.get(i).getTitle() + " " + ar.get(i).getBody()+"\n");
        }
    }
}