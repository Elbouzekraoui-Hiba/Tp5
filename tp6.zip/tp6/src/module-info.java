/**
 * 
 */
/**
 * @author Eleve
 *
 */
module tp3 {
	requires javafx.graphics;
	requires javafx.fxml;
	requires javafx.controls;
	requires java.sql;
	
	opens tp3 to javafx.graphics, javafx.fxml;
}